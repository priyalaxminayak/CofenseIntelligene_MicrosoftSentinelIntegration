"""Download Report Module."""
import logging
import inspect
import requests
import azure.functions as func
from ..SharedCode import consts
from ..SharedCode.logger import applogger


def main(req: func.HttpRequest) -> func.HttpResponse:
    """Download the file and return as http response.

    Args:
        req (func.HttpRequest): _description_

    Returns:
        func.HttpResponse: _description_
    """
    __method_name = inspect.currentframe().f_code.co_name

    try:
        logging.info("Python HTTP trigger function processed a request.")

        url = req.params.get("url")
        if url:
            splitted_url = url.rsplit("/", 1)
            file_format = splitted_url[1]
            level_two_split = splitted_url[0].rsplit("/", 1)
            file_name = level_two_split[1]
            response = requests.get(
                url=url,
                auth=(consts.COFENSE_USERNAME, consts.COFENSE_PASSWORD),
                timeout=10,
            )
            if response.status_code == 200:
                applogger.info(
                    "{}(method={}) : {} : Request Success : threat id - {}.".format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        "DownloadThreatReports",
                        file_name,
                    )
                )
                download_file_name = "{}.{}".format(file_name, file_format)
                if file_format == "html":
                    return func.HttpResponse(
                        response.content,
                        mimetype="text/html",
                        headers={
                            "Content-Disposition": f'attachment; filename="{download_file_name}"'
                        },
                    )
                elif file_format == "pdf":
                    return func.HttpResponse(
                        response.content,
                        mimetype="application/pdf",
                        headers={
                            "Content-Disposition": f'attachment; filename="{download_file_name}"'
                        },
                    )
                else:
                    return func.HttpResponse("Wrong File Format.")
            elif response.status_code == 401:
                applogger.error(
                    "{}(method={}) : {} : Error occured : Authentication Failure. "
                    "Provide valid Cofense Username and Cofense Password in Function App:{}'s "
                    "configuration and try again.".format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        "DownloadThreatReports",
                        consts.FUNCTION_APP_NAME,
                    )
                )
                return func.HttpResponse(
                    "Authentication Error: Wrong Credentials. "
                    "Provide valid Cofense Username and Cofense Password in Function App:{}'s "
                    "configuration and try again.".format(consts.FUNCTION_APP_NAME)
                )
            elif response.status_code == 429:
                applogger.error(
                    "{}(method={}) : {} : Error occured : Rate Limit Exceeded.".format(
                        consts.LOGS_STARTS_WITH, __method_name, "DownloadThreatReports"
                    )
                )
                return func.HttpResponse(
                    "Rate Limit Exceeded, Please Try again after some Time."
                )
        else:
            applogger.error(
                "{}(method={}) : {} : Error occured : URL not passed.".format(
                    consts.LOGS_STARTS_WITH, __method_name, "DownloadThreatReports"
                )
            )
            return func.HttpResponse(
                "Url is not passed, Please Pass a url to download."
            )
    except Exception as error:
        applogger.error(
            "{}(method={}) : {} : Error occured : {}.".format(
                consts.LOGS_STARTS_WITH, __method_name, "DownloadThreatReports", error
            )
        )
        return func.HttpResponse("Error : {}".format(error))
