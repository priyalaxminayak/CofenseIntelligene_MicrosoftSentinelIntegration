from SentinelToDefender import defender
from SharedCode.cofense_intelligence_exception import CofenseIntelligenceException
import json
import pytest

MAKE_HTTP_REQUEST_FUNC_PATH = "SharedCode.utils.Utils.make_http_request"

test_json_data = open("test_data_defender_auth.json")
test_data = json.load(test_json_data)


class MockResponse:
    def __init__(self, json_data, status_code, reason=None, text=None):
        self.json_data = json_data
        self.status_code = status_code
        self.reason = reason
        self.text = text

    def json(self):
        return self.json_data


def test_microsoft_defender_authentication_success(mocker, caplog):
    mocker.patch(
        MAKE_HTTP_REQUEST_FUNC_PATH,
        return_value=MockResponse(
            json_data=test_data["Success"],
            status_code=200,
        ),
    )
    defender_obj = defender.MicrosoftDefender()
    assert (
        "COFENSE Intelligence : (method=auth_defender) : SentinelToDefender: MS Defender access token generated successfully."
        in caplog.text
    )
    assert (
        "COFENSE Intelligence : (method=auth_defender) : SentinelToDefender: url: https://login.microsoftonline.com//oauth2/token, Status Code : 200: Microsoft Defender access token generated."
        in caplog.text
    )
    assert defender_obj.bearer_token == test_data["Success"]["access_token"]


def test_microsoft_defender_auth_response_no_access_token(mocker, caplog):
    mocker.patch(
        MAKE_HTTP_REQUEST_FUNC_PATH,
        return_value=MockResponse(
            json_data=test_data["Success_no_access_token"],
            status_code=200,
            reason="Access token not found.",
        ),
    )
    with pytest.raises(CofenseIntelligenceException):
        defender.MicrosoftDefender()
    assert (
        "COFENSE Intelligence : (method=auth_defender) : SentinelToDefender: Access token not found in MS Defender api call."
        in caplog.text
    )
    assert (
        "COFENSE Intelligence : (method=auth_defender) : SentinelToDefender: url: https://login.microsoftonline.com//oauth2/token, Status Code : 200, Response reason: Access token not found., Response: None : Access token not found in MS Defender authentication api call."
        in caplog.text
    )
    assert (
        "COFENSE Intelligence : (method=auth_defender) : Error generated while getting MS Defender access token : None"
        in caplog.text
    )


def test_microsoft_defender_authentication_bad_request(mocker, caplog):
    mocker.patch(
        MAKE_HTTP_REQUEST_FUNC_PATH,
        return_value=MockResponse(
            json_data=test_data["wrong"], status_code=400, reason="Bad Request."
        ),
    )
    with pytest.raises(CofenseIntelligenceException):
        defender.MicrosoftDefender()
    assert (
        "COFENSE Intelligence : (method=auth_defender) : SentinelToDefender: url: https://login.microsoftonline.com//oauth2/token, Status Code : 400: Error while creating MS Defender access_token. Error Reason: Bad Request."
        in caplog.text
    )
    assert (
        "COFENSE Intelligence : (method=auth_defender) : SentinelToDefender: url: https://login.microsoftonline.com//oauth2/token, Status Code : 400, Response: None : Error while creating MS Defender access token. Error Reason: Bad Request."
        in caplog.text
    )
    assert (
        "COFENSE Intelligence : (method=auth_defender) : Error generated while getting MS Defender access token : None"
        in caplog.text
    )


def test_microsoft_defender_authentication_wrong_client_secret(mocker, caplog):
    mocker.patch(
        "SharedCode.fetch_cofense_indicators.FetchCofenseIndicators.make_http_request",
        return_value=MockResponse(
            json_data=test_data["fail"], status_code=401, reason="Invalid credentials."
        ),
    )
    with pytest.raises(CofenseIntelligenceException):
        defender.MicrosoftDefender()
    assert (
        "COFENSE Intelligence : (method=auth_defender) : SentinelToDefender: url: https://login.microsoftonline.com//oauth2/token, Status Code : 401: Error while creating MS Defender access_token. Error Reason: Invalid credentials."
        in caplog.text
    )
    assert (
        "COFENSE Intelligence : (method=auth_defender) : SentinelToDefender: url: https://login.microsoftonline.com//oauth2/token, Status Code : 401, Response: None : Error while creating MS Defender access token. Error Reason: Invalid credentials."
        in caplog.text
    )
    assert (
        "COFENSE Intelligence : (method=auth_defender) : Error generated while getting MS Defender access token : None"
        in caplog.text
    )
