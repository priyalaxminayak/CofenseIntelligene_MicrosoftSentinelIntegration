"""file for test make http request."""
from SharedCode.utils import Utils, CofenseIntelligenceException
from unittest.mock import MagicMock
from SharedCode import consts
import requests
import json
import pytest

f = open("test_data_make_http_request.json")
test_data = json.load(f)
MOCK_REQUEST_PATH = "SharedCode.utils.requests.Session.get"
MOCK_REQUEST_PATH_POST = "SharedCode.utils.requests.Session.post"


class MockResponse:
    """Mock response class."""

    def __init__(self, json_data, status_code):
        """Initialize mock response.

        Args:
            json_data (json): data for mock response
            status_code (int): response status code
        """
        self.json_data = json_data
        self.status_code = status_code

    def json(self):
        """To get json response.

        Returns:
            json: response in json format
        """
        return self.json_data


def test_make_http_request_success_200(mocker, caplog):
    """When request is successful.

    Args:
        mocker (Mocker): Mocker object
    """
    mocker.patch(
        MOCK_REQUEST_PATH,
        return_value=MockResponse(test_data["success"], 200),
    )
    utils_obj = Utils(consts.COFENSE_TO_SENTINEL)
    utils_obj.make_http_request(
        url="https://www.threathq.com/apiv1/indicator/search",
        method="GET",
        auth=(consts.COFENSE_USERNAME, consts.COFENSE_PASSWORD),
    )
    assert (
        "COFENSE Intelligence : (method=make_http_request) : CofenseIntelligenceToSentinel: Got the"
        " response from url : https://www.threathq.com/apiv1/indicator/search : Status code : 200"
    ) in caplog.text


def test_make_http_request_401(mocker, caplog):
    """When request returns 401.

    Args:
        mocker (Mocker): Mocker object
    """
    mocker.patch(
        MOCK_REQUEST_PATH,
        return_value=MockResponse(test_data["Unauthorized"], 401),
    )
    utils_obj = Utils(consts.COFENSE_TO_SENTINEL)
    utils_obj.make_http_request(
        url="https://login.microsoftonline.com/3adb963c-8e61-48e8-a06d-6dbb0dacea39/oauth2/token",
        method="GET",
        auth=(consts.COFENSE_USERNAME, consts.COFENSE_PASSWORD),
    )
    assert (
        "COFENSE Intelligence : (method=make_http_request) : CofenseIntelligenceToSentinel:"
        " url: https://login.microsoftonline.com/"
        "3adb963c-8e61-48e8-a06d-6dbb0dacea39/oauth2/token, Status Code : 401: error occurred while calling url."
    ) in caplog.text


def test_make_http_request_500(mocker, caplog):
    """When request returns 500.

    Args:
        mocker (Mocker): Mocker object
    """
    mocker.patch(
        MOCK_REQUEST_PATH,
        return_value=MockResponse(test_data["fail"], 500),
    )
    utils_obj = Utils(consts.COFENSE_TO_SENTINEL)
    utils_obj.make_http_request(
        url="https://login.microsoftonline.com/3adb963c-8e61-48e8-a06d-6dbb0dacea39/oauth2/token",
        method="GET",
        auth=(consts.COFENSE_USERNAME, consts.COFENSE_PASSWORD),
    )
    assert (
        "COFENSE Intelligence : (method=make_http_request) : CofenseIntelligenceToSentinel: url: https://login.microso"
        "ftonline.com/3adb963c-8e61-48e8-a06d-6dbb0dacea39/oauth2/token, Status Code : 500: Internal Server Error"
    ) in caplog.text


def test_make_http_request_cofense_exception(mocker, caplog):
    """When http request raises cofense exception.

    Args:
        mocker (Mocker): Mocker object
    """
    mocker.patch(
        MOCK_REQUEST_PATH,
        new=MagicMock(
            side_effect=CofenseIntelligenceException("Cofense exception occurred.")
        ),
    )
    utils_obj = Utils(consts.COFENSE_TO_SENTINEL)

    with pytest.raises(CofenseIntelligenceException):
        utils_obj.make_http_request(
            url="https://www.threathq.com/apiv1/indicator/search",
            method="GET",
            auth=(consts.COFENSE_USERNAME, consts.COFENSE_PASSWORD),
        )
    assert (
        "COFENSE Intelligence : (method=make_http_request) : CofenseIntelligenceToSentinel: Cofense exception occurred."
        in caplog.text
    )


def test_make_http_request_ConnectionError(mocker, caplog):
    """When http request raises Connection error.

    Args:
        mocker (Mocker): Mocker object
    """
    mocker.patch(
        MOCK_REQUEST_PATH_POST,
        new=MagicMock(
            side_effect=requests.ConnectionError("Connection error occurred.")
        ),
    )
    utils_obj = Utils(consts.COFENSE_TO_SENTINEL)
    with pytest.raises(CofenseIntelligenceException):
        utils_obj.make_http_request(
            url="https://www.threathq.com/apiv1/indicator/search",
            method="POST",
            auth=(consts.COFENSE_USERNAME, consts.COFENSE_PASSWORD),
        )

    assert (
        "COFENSE Intelligence : (method=make_http_request) : CofenseIntelligenceToSentinel: Connection error occurred."
        in caplog.text
    )


def test_make_http_request_HTTPError(mocker, caplog):
    """When http request raises HTTP error.

    Args:
        mocker (Mocker): Mocker object
    """
    mocker.patch(
        MOCK_REQUEST_PATH,
        new=MagicMock(side_effect=requests.HTTPError("Http error occurred.")),
    )
    utils_obj = Utils(consts.COFENSE_TO_SENTINEL)
    with pytest.raises(CofenseIntelligenceException):
        utils_obj.make_http_request(
            url="https://www.threathq.com/apiv1/threat/malware/316440",
            method="GET",
            auth=(consts.COFENSE_USERNAME, consts.COFENSE_PASSWORD),
        )
    assert (
        "COFENSE Intelligence : (method=make_http_request) : CofenseIntelligenceToSentinel: Http error occurred."
        in caplog.text
    )


def test_make_http_request_RequestException(mocker, caplog):
    """When http request raises request exception.

    Args:
       mocker (Mocker): Mocker object
    """
    mocker.patch(
        MOCK_REQUEST_PATH,
        new=MagicMock(
            side_effect=requests.RequestException("Request exception occurred")
        ),
    )
    utils_obj = Utils(consts.COFENSE_TO_SENTINEL)
    with pytest.raises(CofenseIntelligenceException):
        utils_obj.make_http_request(
            url="https://www.threathq.com/apiv1/threat/malware/316440",
            method="GET",
            auth=(consts.COFENSE_USERNAME, consts.COFENSE_PASSWORD),
        )
    assert (
        "COFENSE Intelligence : (method=make_http_request) : CofenseIntelligenceToSentinel: Request exception occurred"
        in caplog.text
    )
