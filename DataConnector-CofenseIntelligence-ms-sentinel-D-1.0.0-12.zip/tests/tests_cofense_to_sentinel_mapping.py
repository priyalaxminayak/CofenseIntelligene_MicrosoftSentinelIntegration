"""Unit testing for cofense_to_sentinel_mapping."""
import json
from CofenseToSentinel.cofense_to_sentinel_mapping import map_indicator_fields


def test_workflow(caplog):
    """Test the normal workflow of the code such that it is giving the desired output."""
    with open("mapping_input.json", "r", encoding="utf-8") as f:
        indicator_data = json.load(f)
    mapped_data = map_indicator_fields(indicator_data)
    with open("mapping_output.json", "r", encoding="utf-8") as f:
        real_mapped = json.load(f)
    assert mapped_data == real_mapped["normal"], (
        "INFO     azure:cofense_to_sentinel_mapping.py:52 COFENSE Intelligence : (method=map_indicator_fields) : CofenseIntelligenceToSentinel : Indicator Field Mapping is done for threat 319377."
        in caplog.text
    )


def test_impact_value_minor():
    """Test when the impact value is minor in the input."""
    with open("mapping_input.json", "r", encoding="utf-8") as f:
        indicator_data = json.load(f)
    indicator_data["impact"] = "Minor"
    mapped_data = map_indicator_fields(indicator_data)
    with open("mapping_output.json", "r", encoding="utf-8") as f:
        real_mapped = json.load(f)
        real_mapped["normal"]["properties"]["confidence"] = 30
    assert mapped_data == real_mapped["normal"]


def test_impact_value_major():
    """Test when the impact value is major in the input."""
    with open("mapping_input.json", "r", encoding="utf-8") as f:
        indicator_data = json.load(f)
    indicator_data["impact"] = "Major"
    mapped_data = map_indicator_fields(indicator_data)
    with open("mapping_output.json", "r", encoding="utf-8") as f:
        real_mapped = json.load(f)
        real_mapped["normal"]["properties"]["confidence"] = 100
    assert mapped_data == real_mapped["normal"]


def test_impact_value_medium():
    """Test when the impact value is medium in the input."""
    with open("mapping_input.json", "r", encoding="utf-8") as f:
        indicator_data = json.load(f)
    indicator_data["impact"] = "Medium"
    mapped_data = map_indicator_fields(indicator_data)
    with open("mapping_output.json", "r", encoding="utf-8") as f:
        real_mapped = json.load(f)
        real_mapped["normal"]["properties"]["confidence"] = 70
    assert mapped_data == real_mapped["normal"]


def test_impact_value_moderate():
    """Test when the impact value is moderate in the input."""
    with open("mapping_input.json", "r", encoding="utf-8") as f:
        indicator_data = json.load(f)
    indicator_data["impact"] = "Moderate"
    mapped_data = map_indicator_fields(indicator_data)
    with open("mapping_output.json", "r", encoding="utf-8") as f:
        real_mapped = json.load(f)
        real_mapped["normal"]["properties"]["confidence"] = 50
    assert mapped_data == real_mapped["normal"]


def test_impact_value_none():
    """Test when the impact value is none in the input."""
    with open("mapping_input.json", "r", encoding="utf-8") as f:
        indicator_data = json.load(f)
    indicator_data["impact"] = "None"
    mapped_data = map_indicator_fields(indicator_data)
    with open("mapping_output.json", "r", encoding="utf-8") as f:
        real_mapped = json.load(f)
        real_mapped["normal"]["properties"]["confidence"] = 1
    assert mapped_data == real_mapped["normal"]


def test_indicator_type_file():
    """Test when the indicator type is file in the input."""
    with open("mapping_input.json", "r", encoding="utf-8") as f:
        indicator_data = json.load(f)
    indicator_data["indicator_type"] = "File"
    mapped_data = map_indicator_fields(indicator_data)
    with open("mapping_output.json", "r", encoding="utf-8") as f:
        real_mapped = json.load(f)
    assert mapped_data == real_mapped["file"]


def test_indicator_type_url():
    """Test when the indicator type is url in the input."""
    with open("mapping_input.json", "r", encoding="utf-8") as f:
        indicator_data = json.load(f)
    indicator_data["indicator_type"] = "URL"
    mapped_data = map_indicator_fields(indicator_data)
    with open("mapping_output.json", "r", encoding="utf-8") as f:
        real_mapped = json.load(f)
    assert mapped_data == real_mapped["url"]


def test_indicator_type_domain_name():
    """Test when the indicator type is domain name in the input."""
    with open("mapping_input.json", "r", encoding="utf-8") as f:
        indicator_data = json.load(f)
    indicator_data["indicator_type"] = "Domain Name"
    mapped_data = map_indicator_fields(indicator_data)
    with open("mapping_output.json", "r", encoding="utf-8") as f:
        real_mapped = json.load(f)
    assert mapped_data == real_mapped["domain"]

def test_indicator_type_none():
    """Test when the indicator type is domain name in the input."""
    with open("mapping_input.json", "r", encoding="utf-8") as f:
        indicator_data = json.load(f)
    indicator_data["indicator_type"] = ""
    mapped_data = map_indicator_fields(indicator_data)
    with open("mapping_output.json", "r", encoding="utf-8") as f:
        real_mapped = json.load(f)
    assert mapped_data == real_mapped["none"]
