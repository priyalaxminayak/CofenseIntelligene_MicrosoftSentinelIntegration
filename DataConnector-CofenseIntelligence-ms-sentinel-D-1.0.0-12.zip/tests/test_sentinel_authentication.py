"""this file contents the testing methods for azure sentinel authentication method"""
from SharedCode import utils
from SharedCode import consts
from SharedCode.cofense_intelligence_exception import CofenseIntelligenceException
import json
import pytest

# Opening test data file
f = open('tests/test_data_API_response.json')
test_data = json.load(f)

MAKE_HTTP_REQUEST_PATH = "SharedCode.utils.Utils.make_http_request"
class MockResponse:
    def __init__(self, json_data, status_code, reason=None):
        self.json_data = json_data
        self.status_code = status_code
        self.reason = reason

    def json(self):
        return self.json_data


def test_auth_sentinel_success(mocker, caplog):
    """When every parameter is set correctly API will throw 200 status code.

    Args:
        mocker (API response): this will mock the response of "https://login.microsoftonline.com/{tenant}/oauth2/token"
    """
    mocker.patch(MAKE_HTTP_REQUEST_PATH,
                 return_value=MockResponse(
                     json_data=test_data["Success"],
                     status_code=200
                     )
                 )
    Utils_obj = utils.Utils(azure_function_name='sentinel_authentication')
    azure_auth_url = consts.AZURE_AUTHENTICATION_URL.format(
                consts.AZURE_TENANT_ID
            )
    assert Utils_obj.auth_sentinel() == test_data["Success"]["access_token"]
    assert ("{}(method={}) : {}: Microsoft sentinel access token generated successfully.".format(
                            consts.LOGS_STARTS_WITH, "auth_sentinel", "sentinel_authentication"
                        )) in caplog.text
    assert ("{}(method={}) : {}: url: {}, Status Code : {}: Microsoft Sentinel access token generated.".format(
                            consts.LOGS_STARTS_WITH,
                            "auth_sentinel",
                            "sentinel_authentication",
                            azure_auth_url,
                            200,
                        )
            ) in caplog.text

def test_auth_sentinel_fail(mocker, caplog):
    """When user passes wrong client secret.

    Args:
        mocker (API response): this will mock the response "https://login.microsoftonline.com/{tenant}/oauth2/token"
    """
    mocker.patch(MAKE_HTTP_REQUEST_PATH,
                return_value=MockResponse(
                    json_data=test_data["fail"],
                    reason="Unauthorized",
                    status_code=401
                    )
                )
    Utils_obj = utils.Utils(azure_function_name='sentinel_authentication')
    azure_auth_url = consts.AZURE_AUTHENTICATION_URL.format(
            consts.AZURE_TENANT_ID
        )
    with pytest.raises(CofenseIntelligenceException):
        Utils_obj.auth_sentinel()
    assert ("{}(method={}) : {}: url: {}, Status Code : {}: Error while creating microsoft sentinel access_token."
                    " Error Reason: {}".format(
                        consts.LOGS_STARTS_WITH,
                        "auth_sentinel",
                        "sentinel_authentication",
                        azure_auth_url,
                        401,
                        "Unauthorized",
                    )
            ) in caplog.text
    assert ("{}(method={}) : Error generated while getting sentinel access token :{}".format(
                    consts.LOGS_STARTS_WITH, "auth_sentinel", ""
                )
            ) in caplog.text

def test_auth_sentinel_not_has_access_token(mocker, caplog):
    """When user passes wrong client secret.

    Args:
        mocker (API response): this will mock the response "https://login.microsoftonline.com/{tenant}/oauth2/token"
    """
    mocker.patch(MAKE_HTTP_REQUEST_PATH,
                return_value=MockResponse(
                    json_data=test_data["Success_not_access_token"],
                    status_code=200
                    )
                )
    Utils_obj = utils.Utils(azure_function_name='sentinel_authentication')
    with pytest.raises(CofenseIntelligenceException):
        Utils_obj.auth_sentinel()
    assert ("{}(method={}) : {}: Access token not found in sentinel api call.".format(
                            consts.LOGS_STARTS_WITH, "auth_sentinel", "sentinel_authentication"
                        )
            ) in caplog.text

def test_auth_sentinel_wrong_tenant(mocker, caplog):
    """When user passes wrong tenant Id

    Args:
        mocker (API response): this will mock the response "https://login.microsoftonline.com/{tenant}/oauth2/token"
    """
    mocker.patch(MAKE_HTTP_REQUEST_PATH,
                return_value=MockResponse(
                    json_data=test_data["wrong"],
                    reason="Bad Request",
                    status_code=400
                    )
                )
    azure_auth_url = consts.AZURE_AUTHENTICATION_URL.format(
        consts.AZURE_TENANT_ID
    )
    Utils_obj = utils.Utils(azure_function_name='sentinel_authentication')
    with pytest.raises(CofenseIntelligenceException):
        Utils_obj.auth_sentinel()
    assert ("{}(method={}) : {}: url: {}, Status Code : {}: Error while creating microsoft sentinel access_token."
                    " Error Reason: {}".format(
                        consts.LOGS_STARTS_WITH,
                        "auth_sentinel",
                        "sentinel_authentication",
                        azure_auth_url,
                        400,
                        "Bad Request",
                    )
            ) in caplog.text
    assert ("{}(method={}) : Error generated while getting sentinel access token :{}".format(
            consts.LOGS_STARTS_WITH, "auth_sentinel", ""
        )) in caplog.text
