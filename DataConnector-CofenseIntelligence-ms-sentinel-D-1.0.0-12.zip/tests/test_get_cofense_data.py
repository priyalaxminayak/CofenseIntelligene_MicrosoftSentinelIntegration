"""file for test get cofense data."""
from SharedCode.utils import Utils, CofenseIntelligenceException
from unittest.mock import MagicMock
from SharedCode import consts
import json
import pytest

f = open("test_data_get_cofense_data.json")
test_data = json.load(f)
PATH_MOCK_HTTP_REQUEST = "SharedCode.utils.Utils.make_http_request"


class MockResponse:
    """Mock response class."""

    def __init__(self, json_data, status_code):
        """Initialize mock response.

        Args:
            json_data (json): data for mock response
            status_code (int): response status code
        """
        self.json_data = json_data
        self.status_code = status_code

    def json(self):
        """To get json response.

        Returns:
            json: response in json format
        """
        return self.json_data


def test_get_cofense_data_success_200(mocker):
    """When cofense data request success.

    Args:
        mocker (Mocker): Mocker object
    """
    mocker.patch(
        PATH_MOCK_HTTP_REQUEST,
        return_value=MockResponse(
            test_data["success"],
            200,
        ),
    )
    utils_obj = Utils(consts.COFENSE_TO_SENTINEL)
    res = utils_obj.get_cofense_data(
        url="https://www.threathq.com/apiv1/indicator/search",
        endpoint_name="get indicators",
    )
    assert res == test_data["success"]


def test_get_cofense_data_401(mocker, caplog):
    """When 401 status code returned.

    Args:
        mocker (Mocker): Mocker object
    """
    mocker.patch(
        PATH_MOCK_HTTP_REQUEST,
        return_value=MockResponse(
            test_data["Unauthorized"],
            401,
        ),
    )
    utils_obj = Utils(consts.COFENSE_TO_SENTINEL)
    with pytest.raises(CofenseIntelligenceException):
        utils_obj.get_cofense_data(
            url="https://www.threathq.com/apiv1/threat/malware/316440",
            endpoint_name="get Malware",
        )
    assert (
        "COFENSE Intelligence : (method=get_cofense_data) : CofenseIntelligenceToSentinel : trying again error 401 in get Malware."
        in caplog.text
    )
    assert (
        "COFENSE Intelligence : (method=get_cofense_data) : CofenseIntelligenceToSentinel : Max retries exceeded in get Malware while fetching data."
        in caplog.text
    )
    assert (
        "COFENSE Intelligence : (method=get_cofense_data) : CofenseIntelligenceToSentinel : error in get Malware while pulling data of indicator."
        in caplog.text
    )


def test_get_cofense_data_429(mocker, caplog):
    """When 429 status code returned.

    Args:
        mocker (Mocker): Mocker object
    """
    mocker.patch(
        PATH_MOCK_HTTP_REQUEST,
        return_value=MockResponse(
            test_data["fail"],
            429,
        ),
    )
    utils_obj = Utils(consts.COFENSE_TO_SENTINEL)
    with pytest.raises(CofenseIntelligenceException):
        utils_obj.get_cofense_data(
            url="https://www.threathq.com/apiv1/indicator/search",
            endpoint_name="get indicators",
        )
    assert (
        "COFENSE Intelligence : (method=get_cofense_data) : CofenseIntelligenceToSentinel : trying again error 429 in get indicators."
        in caplog.text
    )
    assert (
        "COFENSE Intelligence : (method=get_cofense_data) : CofenseIntelligenceToSentinel : Max retries exceeded in get indicators while fetching data."
        in caplog.text
    )
    assert (
        "COFENSE Intelligence : (method=get_cofense_data) : CofenseIntelligenceToSentinel : error in get indicators while pulling data of indicator."
        in caplog.text
    )


def test_get_cofense_data_500(mocker, caplog):
    """When 500 status code returned.

    Args:
        mocker (Mocker): Mocker object
    """
    mocker.patch(
        PATH_MOCK_HTTP_REQUEST,
        return_value=MockResponse(
            test_data["fail"],
            500,
        ),
    )
    utils_obj = Utils(consts.COFENSE_TO_SENTINEL)
    with pytest.raises(CofenseIntelligenceException):
        utils_obj.get_cofense_data(
            url="https://www.threathq.com/apiv1/indicator/search",
            endpoint_name="get indicators",
        )
    assert (
        "COFENSE Intelligence : (method=get_cofense_data) : CofenseIntelligenceToSentinel : url: https://www.threathq.com/apiv1/indicator/search, Status Code : 500 : error in get indicators."
        in caplog.text
    )
    assert (
        "COFENSE Intelligence : (method=get_cofense_data) : CofenseIntelligenceToSentinel : error in get indicators while pulling data of indicator."
        in caplog.text
    )


def test_get_cofense_data_CofenseException(mocker, caplog):
    """When cofense exception occurred.

    Args:
        mocker (Mocker): Mocker object
    """
    mocker.patch(
        PATH_MOCK_HTTP_REQUEST,
        new=MagicMock(side_effect=CofenseIntelligenceException()),
    )
    utils_obj = Utils(consts.COFENSE_TO_SENTINEL)
    with pytest.raises(CofenseIntelligenceException):
        utils_obj.get_cofense_data(
            url="https://www.threathq.com/apiv1/threat/malware/316440",
            endpoint_name="get Malware",
        )
    assert (
        "COFENSE Intelligence : (method=get_cofense_data) : CofenseIntelligenceToSentinel : error in get Malware while pulling data of indicator."
        in caplog.text
    )


def test_get_cofense_data_Exception(mocker, caplog):
    """When exception occurred.

    Args:
        mocker (Mocker): Mocker object
    """
    mocker.patch(
        PATH_MOCK_HTTP_REQUEST,
        new=MagicMock(side_effect=ValueError("Value error occurred")),
    )
    utils_obj = Utils(consts.COFENSE_TO_SENTINEL)
    with pytest.raises(CofenseIntelligenceException):
        utils_obj.get_cofense_data(
            url="https://www.threathq.com/apiv1/threat/malware/316440",
            endpoint_name="get Malware",
        )
    assert (
        "COFENSE Intelligence : (method=get_cofense_data) : CofenseIntelligenceToSentinel : error in get Malware while pulling data of indicator: Value error occurred."
        in caplog.text
    )
