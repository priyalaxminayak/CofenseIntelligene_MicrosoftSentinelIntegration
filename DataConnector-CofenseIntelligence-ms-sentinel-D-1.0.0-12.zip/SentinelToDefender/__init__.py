"""This __init__ file will be called once triggered is generated."""
import datetime
from ..SharedCode import consts
from .sentinel import MicrosoftSentinel
from ..SharedCode.logger import applogger
import azure.functions as func


def main(mytimer: func.TimerRequest) -> None:
    """Start the execution.

    Args:
        mytimer (func.TimerRequest): timer trigger
    """
    if consts.IS_DEFENDER_USER == "Yes":
        utc_timestamp = datetime.datetime.utcnow().replace(
            tzinfo=datetime.timezone.utc).isoformat()

        microsoft_sentinel = MicrosoftSentinel()
        indicators = microsoft_sentinel.get_indicators_from_sentinel()

        if mytimer.past_due:
            applogger.info('The timer is past due!')

        applogger.info('Python timer trigger function ran at %s', utc_timestamp)
    else:
        applogger.info("Not a defender user.")
