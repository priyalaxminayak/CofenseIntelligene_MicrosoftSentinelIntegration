"""This module contains Microsoftdefender class for authentication."""
import inspect
from ..SharedCode.logger import applogger
from ..SharedCode import consts
from ..SharedCode.utils import Utils
from ..SharedCode.cofense_intelligence_exception import CofenseIntelligenceException


class MicrosoftDefender:
    """This class is for MS Defender authentication."""

    def __init__(self) -> None:
        """Initialize instance variable for class."""
        self.bearer_token = self.auth_defender(consts.SENTINEL_TO_DEFENDER)

    def auth_defender(self, azure_function_name):
        """To authenticate with microsoft defender."""
        __method_name = inspect.currentframe().f_code.co_name
        try:
            applogger.info(
                "{}(method={}) : {}: generating MS Defender access token.".format(
                    consts.LOGS_STARTS_WITH, __method_name, azure_function_name
                )
            )
            azure_auth_url = consts.AZURE_AUTHENTICATION_URL.format(
                consts.AZURE_TENANT_ID
            )
            # Creating body for Microsoft Defender authentication API
            body = {
                "client_id": consts.AZURE_CLIENT_ID,
                "client_secret": consts.AZURE_CLIENT_SECRET,
                "grant_type": "client_credentials",
                "resource": "https://api.securitycenter.microsoft.com/",
            }
            utils_obj = Utils(function_name=consts.SENTINEL_TO_DEFENDER)
            response = utils_obj.make_http_request(
                url=azure_auth_url,
                method="POST",
                azure_function_name=azure_function_name,
                body=body,
            )
            if response.status_code >= 200 and response.status_code <= 299:
                json_response = response.json()
                if "access_token" not in json_response:
                    applogger.error(
                        "{}(method={}) : {}: Access token not found in MS Defender api call.".format(
                            consts.LOGS_STARTS_WITH, __method_name, azure_function_name
                        )
                    )
                    applogger.debug(
                        "{}(method={}) : {}: url: {}, Status Code : {}, Response reason: {}, Response: {} : "
                        "Access token not found in MS Defender authentication api call.".format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            azure_function_name,
                            azure_auth_url,
                            response.status_code,
                            response.reason,
                            response.text,
                        )
                    )
                    raise CofenseIntelligenceException()
                else:
                    bearer_token = json_response.get("access_token")
                    applogger.info(
                        "{}(method={}) : {}: MS Defender access token generated successfully.".format(
                            consts.LOGS_STARTS_WITH, __method_name, azure_function_name
                        )
                    )
                    applogger.debug(
                        "{}(method={}) : {}: url: {}, Status Code : {}: Microsoft Defender access "
                        "token generated.".format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            azure_function_name,
                            azure_auth_url,
                            response.status_code,
                        )
                    )
                    return bearer_token
            else:
                applogger.error(
                    "{}(method={}) : {}: url: {}, Status Code : {}: Error while creating MS "
                    "Defender access_token. Error Reason: {}".format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        azure_function_name,
                        azure_auth_url,
                        response.status_code,
                        response.reason,
                    )
                )
                applogger.debug(
                    "{}(method={}) : {}: url: {}, Status Code : {}, Response: {} : "
                    "Error while creating MS Defender access token. Error Reason: {}".format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        azure_function_name,
                        azure_auth_url,
                        response.status_code,
                        response.text,
                        response.reason,
                    )
                )
                raise CofenseIntelligenceException()
        except CofenseIntelligenceException as error:
            applogger.error(
                "{}(method={}) : Error generated while getting MS Defender access token : {}".format(
                    consts.LOGS_STARTS_WITH, __method_name, error
                )
            )
            raise CofenseIntelligenceException()
