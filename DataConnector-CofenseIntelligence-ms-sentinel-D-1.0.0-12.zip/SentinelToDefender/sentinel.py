"""This file contains method to fetch indicators from sentinel."""
from ..SharedCode.utils import Utils
from ..SharedCode.cofense_intelligence_exception import CofenseIntelligenceException
from ..SharedCode import consts
import inspect
from ..SharedCode.logger import applogger
import json
import time


class MicrosoftSentinel(Utils):
    """This class will fetch the indicators from sentinel.

    Args:
        Utils (class): class contains helper methods.
    """

    def get_indicators_from_sentinel(self):
        """To get indicators from Microsoft Sentinel threat intelligence."""
        try:
            self.sentinel_access_token = self.auth_sentinel(consts.SENTINEL_TO_DEFENDER)
            __method_name = inspect.currentframe().f_code.co_name
            applogger.info(
                "{}(method={}) : {} : "
                "Started fetching cofense indicators from Microsoft Sentinel Threat Intelligence.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.SENTINEL_TO_DEFENDER,
                )
            )
            retry_count_429 = 0
            retry_count_401 = 0
            while retry_count_429 <= 3 and retry_count_401 <= 1:
                query_indicator_url = consts.QUERY_SENTINEL_INDICATORS_URL.format(
                    subscriptionId=consts.AZURE_SUBSCRIPTION_ID,
                    resourceGroupName=consts.AZURE_RESOURCE_GROUP,
                    workspaceName=consts.AZURE_WORKSPACE_NAME,
                )
                headers = {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer {}".format(self.sentinel_access_token),
                }
                applogger.info(
                    "{}(method={}) : {} : "
                    "Started setting body of sentinel cofense indicators "
                    "from Microsoft Sentinel Threat Intelligence.".format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        consts.SENTINEL_TO_DEFENDER,
                        )
                    )
                body = {
                    "pageSize": consts.QUERY_SENTINEL_PAGESIZE,
                    "keywords": "Cofense",
                    "sortBy": [
                        {"itemKey": "lastUpdatedTimeUtc", "sortOrder": "descending"}
                    ],
                    "skipToken": ""
                }

                get_indicator_response = self.make_http_request(
                    url=query_indicator_url,
                    method="POST",
                    azure_function_name=consts.SENTINEL_TO_DEFENDER,
                    body=json.dumps(body),
                    headers=headers,
                )

                # If response status code is 200 to 299.
                if (
                    get_indicator_response.status_code >= 200
                    and get_indicator_response.status_code <= 299
                ):
                    return get_indicator_response

                # response status code is 429.
                if get_indicator_response.status_code == 429:
                    retry_count_429 += 1
                    applogger.error(
                        "{}(method={}) : {}: url: {}, Status Code : {} : "
                        "Getting 429 from sentinel get indicators api call. Retrying again after {} seconds.".format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            consts.SENTINEL_TO_DEFENDER,
                            query_indicator_url,
                            get_indicator_response.status_code,
                            consts.SENTINEL_429_SLEEP,
                        )
                    )
                    applogger.debug(
                        "{}(method={}) : {}: url: {}, Status Code : {}, Response reason: {}, Response: {} : "
                        "Getting 429 from sentinel get indicators api call. Retry count: {}.".format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            consts.SENTINEL_TO_DEFENDER,
                            query_indicator_url,
                            get_indicator_response.status_code,
                            get_indicator_response.reason,
                            get_indicator_response.text,
                            retry_count_429,
                        )
                    )
                    # sleep for 60 seconds.
                    time.sleep(consts.SENTINEL_429_SLEEP)

                # response is 401, access token is expired.
                elif get_indicator_response.status_code == 401:
                    retry_count_401 += 1
                    applogger.error(
                        "{}(method={}) : {} : url: {}, Status Code : {}:  Error Reason: {} : "
                        "Sentinel access token expired, generating new access token.".format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            consts.SENTINEL_TO_DEFENDER,
                            query_indicator_url,
                            get_indicator_response.status_code,
                            get_indicator_response.reason,
                        )
                    )
                    applogger.debug(
                        "{}(method={}) : {} : url: {}, Status Code : {}, Error Reason: {}, Response: {} : Sentinel"
                        " access token expired, generating new access token. Retry count: {}.".format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            consts.SENTINEL_TO_DEFENDER,
                            query_indicator_url,
                            get_indicator_response.status_code,
                            get_indicator_response.reason,
                            get_indicator_response.text,
                            retry_count_401,
                        )
                    )
                    self.bearer_token = self.auth_sentinel(consts.SENTINEL_TO_DEFENDER)

                # response status code is not 200 to 299, 429 and 401.
                else:
                    applogger.error(
                        "{}(method={}) : {} : url: {}, Status Code : {} : Error while fetching indicators"
                        " from sentinel threat intelligence. Error Reason: {}".format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            consts.SENTINEL_TO_DEFENDER,
                            query_indicator_url,
                            get_indicator_response.status_code,
                            get_indicator_response.reason,
                        )
                    )
                    applogger.debug(
                        "{}(method={}) : {} : url: {}, Status Code : {}, Error Reason: {}, Response: {} :"
                        " Error while fetching indicators from sentinel threat intelligence.".format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            consts.SENTINEL_TO_DEFENDER,
                            query_indicator_url,
                            get_indicator_response.status_code,
                            get_indicator_response.reason,
                            get_indicator_response.text,
                        )
                    )
                    # raise the exception to exit the function app.
                    raise CofenseIntelligenceException()

            # retry count exceeded.
            applogger.error(
                "{}(method={}) : {} : Max retries exceeded for fetching indicators from sentinel.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.SENTINEL_TO_DEFENDER,
                )
            )
            # raising the exception to exit the function app.
            raise CofenseIntelligenceException()

        except CofenseIntelligenceException:
            raise CofenseIntelligenceException()
